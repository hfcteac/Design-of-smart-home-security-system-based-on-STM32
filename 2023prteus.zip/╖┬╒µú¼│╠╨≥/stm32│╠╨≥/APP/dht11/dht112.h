
#ifndef _DHT112_H
#define _DHT112_H

#include "system.h"
#include "SysTick.h"


#define DHT112 				GPIO_Pin_1
#define GPIO_DHT112 			GPIOB
#define DHT112_PORT_RCC		RCC_APB2Periph_GPIOB

#define DHT112_DQ_IN 		PBin(1)	//����
#define DHT112_DQ_OUT 		PBout(1)  //���






#define DHT11 				GPIO_Pin_15
#define GPIO_DHT11 			GPIOB
#define DHT11_PORT_RCC		RCC_APB2Periph_GPIOB

#define DHT11_DQ_IN 		PBin(15)	//����
#define DHT11_DQ_OUT 		PBout(15)  //���

void DHT112_IO_OUT(void);
void DHT112_IO_IN(void);
u8 DHT112_Init(void);
void DHT112_Rst(void);
u8 DHT112_Check(void);
u8 DHT112_Read_Bit(void);
u8 DHT112_Read_Byte(void);
u8 DHT112_Read_Data(u8 *temp,u8 *humi);


void DHT11_IO_OUT(void);
void DHT11_IO_IN(void);
u8 DHT11_Init(void);
void DHT11_Rst(void);
u8 DHT11_Check(void);
u8 DHT11_Read_Bit(void);
u8 DHT11_Read_Byte(void);
u8 DHT11_Read_Data(u8 *temp,u8 *humi);

#endif
