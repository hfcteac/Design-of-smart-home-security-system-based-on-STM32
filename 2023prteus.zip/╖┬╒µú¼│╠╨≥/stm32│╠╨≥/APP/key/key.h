
#ifndef _key_H
#define _key_H


#include "system.h"
 
#define KEY1_PIN   			GPIO_Pin_6    	
#define KEY2_PIN    		GPIO_Pin_7    	
#define KEY3_PIN    		GPIO_Pin_8    	
#define KEY4_PIN  			GPIO_Pin_9 
#define KEY5_PIN  			GPIO_Pin_5 

#define KEY_PORT 			GPIOB 			

//ʹ��λ��������
#define KEY5 	PBin(5)
#define KEY1 	PBin(6)
#define KEY2 	PBin(7)
#define KEY3 	PBin(8)
#define KEY4 	PBin(9)


//�����������ֵ  
#define KEY1_PRESS 		1
#define KEY2_PRESS		2
#define KEY3_PRESS		3
#define KEY4_PRESS		4
#define KEY5_PRESS		5
 
void KEY_Init(void);
u8 KEY_Scan(u8 mode);

#endif
