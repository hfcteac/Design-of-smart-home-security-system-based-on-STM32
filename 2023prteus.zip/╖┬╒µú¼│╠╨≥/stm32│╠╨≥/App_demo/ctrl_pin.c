#include "ctrl_pin.h"

//�������ų�ʼ��
void ctrl_pin_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(SW_RELAY_PORT_RCC,ENABLE); 
	RCC_APB2PeriphClockCmd(JW_RELAY_PORT_RCC,ENABLE); 	

	GPIO_InitStructure.GPIO_Pin=SW_RELAY_PIN;		
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;		
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;	  
	GPIO_Init(SW_RELAY_PORT,&GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin=JW_RELAY_PIN;		 
	GPIO_Init(JW_RELAY_PORT,&GPIO_InitStructure);
	
	GPIO_SetBits(SW_RELAY_PORT,SW_RELAY_PIN);
	GPIO_SetBits(JW_RELAY_PORT,JW_RELAY_PIN);
}
