#ifndef _beep_H
#define _beep_H

#include "system.h"

/*  ������ʱ�Ӷ˿ڡ����Ŷ��� */
#define BEEP_PORT 			GPIOB   
#define BEEP_PIN 			GPIO_Pin_14
#define BEEP_PORT_RCC		RCC_APB2Periph_GPIOB

#define BEEP PBout(14)
/*  ledʱ�Ӷ˿ڡ����Ŷ��� */
#define LEDR_PORT 			GPIOA
#define LEDB_PORT 			GPIOA 
#define LEDY_PORT 			GPIOA 

#define LEDR_PIN 			GPIO_Pin_0
#define LEDB_PIN 			GPIO_Pin_1
#define LEDY_PIN 			GPIO_Pin_2

#define LEDR_PORT_RCC		RCC_APB2Periph_GPIOA
#define LEDB_PORT_RCC		RCC_APB2Periph_GPIOA
#define LEDY_PORT_RCC		RCC_APB2Periph_GPIOA

#define LEDR PAout(0)
#define LEDB PAout(1)
#define LEDY PAout(2)

/*  ���ȡ�ˮ��ʱ�Ӷ˿ڡ����Ŷ��� */
#define MOTO_PORT 			GPIOA
#define COLD_PORT 			GPIOA
#define HOT_PORT 				GPIOA
#define PUMP_PORT 			GPIOA
#define WET_PORT 				GPIOA
#define DRY_PORT 			GPIOA

#define MOTO_PIN 			GPIO_Pin_3
#define COLD_PIN 			GPIO_Pin_5
#define HOT_PIN 			GPIO_Pin_6
#define PUMP_PIN 			GPIO_Pin_7
#define WET_PIN 			GPIO_Pin_4
#define DRY_PIN 			GPIO_Pin_8

#define MOTO_PORT_RCC		RCC_APB2Periph_GPIOA
#define COLD_PORT_RCC		RCC_APB2Periph_GPIOA
#define HOT_PORT_RCC		RCC_APB2Periph_GPIOA
#define PUMP_PORT_RCC		RCC_APB2Periph_GPIOA
#define WET_PORT_RCC		RCC_APB2Periph_GPIOA
#define DRY_PORT_RCC		RCC_APB2Periph_GPIOA

#define MOTO PAout(3)
#define COLD PAout(5)
#define HOT PAout(6)
#define PUMP PAout(7)
#define WET PAout(4)
#define DRY PAout(8)

void BEEP_Init(void);
void LEDR_Init(void);
//void LEDB_Init(void);
//void LEDY_Init(void);
//void MOTO_Init(void);
//void COLD_Init(void);
//void HOT_Init(void);
//void PUMP_Init(void);
void beep_alarm(u16 time,u16 fre);
//void allinit(void);
#endif
