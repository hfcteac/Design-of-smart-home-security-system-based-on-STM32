#ifndef _app_demo_H
#define _app_demo_H


#include "system.h"





//����ṹ��
typedef struct
{
	u8 temp;
	u8 humi;
	u8 light;
	u8 wind;
	u8 outtemp;
	u8 outhumi;	
  u8 oxy;
	
}_sys_ctrl;
extern _sys_ctrl sys_ctrl;

#endif
