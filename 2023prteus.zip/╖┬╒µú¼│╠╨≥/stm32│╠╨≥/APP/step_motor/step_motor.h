
#ifndef _step_motor_H
#define _step_motor_H

#include "system.h"

//����ULN2003���Ʋ�������ܽ�
#define IN1_A_PORT 				GPIOB   
#define IN1_A_PIN 				GPIO_Pin_10
#define IN1_A_PORT_RCC			RCC_APB2Periph_GPIOB

#define IN1_B_PORT 				GPIOB   
#define IN1_B_PIN 				GPIO_Pin_11
#define IN1_B_PORT_RCC			RCC_APB2Periph_GPIOB

#define IN1_C_PORT 				GPIOB   
#define IN1_C_PIN 				GPIO_Pin_12
#define IN1_C_PORT_RCC			RCC_APB2Periph_GPIOB

#define IN1_D_PORT 				GPIOB   
#define IN1_D_PIN 				GPIO_Pin_13
#define IN1_D_PORT_RCC			RCC_APB2Periph_GPIOB

#define IN1_A 					PBout(10)
#define IN1_B 					PBout(11)
#define IN1_C 					PBout(12)
#define IN1_D 					PBout(13)

extern int jiaodu;

// ���岽������ٶȣ�ֵԽС���ٶ�Խ��
// ��С����С��1
#define STEPMOTOR_MAXSPEED        50  
#define STEPMOTOR_MINSPEED        100

//��������
void step_motor_gpio_init(void);
void step_motor_28BYJ48_send_pulse(u8 step,u8 dir,u8 speed,u16 angle,u8 sta);

#endif
